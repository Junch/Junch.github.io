Please insert the following three lines into the .vcxproj file after the line </PropertyGroup>.

  <ImportGroup Label="PropertySheets">
    <Import Project="$(GMOCK_HOME)\props\gmock.props" />
  </ImportGroup>
 